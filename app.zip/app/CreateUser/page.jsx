import React from 'react'

const CreateUser = () => {
    return (
        <div>
            <h1>Only admins</h1>
        </div>
    )
}

export default CreateUser
