import React from "react";

const Denied = () => {
    return (
        <div>
            <h1 className="text-red-400">Denied</h1>
        </div>
    );
};

export default Denied;