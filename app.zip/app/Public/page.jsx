import React from 'react'

const Public = () => {
    return (
        <div>
            <h1>Public</h1>
        </div>
    )
}

export default Public
